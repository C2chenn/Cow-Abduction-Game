﻿using UnityEngine;
using System.Collections;

public class attackerscript : MonoBehaviour {
	private Vector2 velocity = new Vector2(3, 0);
	private Vector3 end;
	private float start;
	private float timestamp;
	private bool hit = false;
	private int lives;
	GameObject life_text;
	TextMesh text;
	void Start () {
		GetComponent<Rigidbody2D>().velocity = velocity;
		life_text = GameObject.FindGameObjectWithTag ("life");
		text = life_text.GetComponent<TextMesh>();
		transform.position = new Vector3(-8 , Random.Range(-4, 6), transform.position.z);
		end = new Vector3(8, transform.position.y, transform.position.z);
	}
	
	// Update is called once per frame
	void Update () {
		if (transform.position.x >= end.x) {
			Destroy(gameObject);
		}
		if (hit) {
			timestamp = Time.time;
			if(timestamp > start + 3){
				Destroy (gameObject);
			}		
		}
	}

	void OnCollisionEnter2D(Collision2D other){
		start = Time.time;
		hit = true;
		lives = int.Parse(text.text);
		lives--;
		text.text = lives.ToString(); 
	}
}
