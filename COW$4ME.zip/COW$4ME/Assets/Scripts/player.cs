﻿using UnityEngine;
using System.Collections;

public class player : MonoBehaviour {
	private Vector3 mousePoint;
	public float speed = 0.1f;
	public GameObject roaming;
	public GameObject abducting;
	public GameObject beam;
	public GameObject sad;

	// Use this for initialization
	void Start () {

	
	}
	
	// Update is called once per frame
	void Update () {
		mousePoint = Input.mousePosition;
		mousePoint = Camera.main.ScreenToWorldPoint (mousePoint);
		if(mousePoint.x < 8 && mousePoint.x > -8 && mousePoint.y < 6 && mousePoint.y > -6 ){
		transform.position = Vector2.Lerp (transform.position, mousePoint, speed);
		if (Input.GetMouseButton (0)) {
			abducting.SetActive(true);
			beam.SetActive(true);
			roaming.SetActive(false);
			sad.SetActive(false);


		
		}
		else {
			roaming.SetActive(true);
			beam.SetActive(false);
			abducting.SetActive(false);

		}
		}
		if (Input.GetKeyDown(KeyCode.Escape)) {
			Application.Quit();
		}

	}
 

	void OnCollisionEnter2D(Collision2D other){
		Debug.Log ("collided");
		sad.SetActive (true);
		roaming.SetActive (false);
	}
}
