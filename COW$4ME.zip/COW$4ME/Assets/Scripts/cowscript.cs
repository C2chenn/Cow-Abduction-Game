﻿using UnityEngine;
using System.Collections;

public class cowscript : MonoBehaviour {
	private GameObject ship_pos;
	private Vector2 velocity = new Vector2(2, 0);
	private Vector3 end;
	public GameObject alive;
	public GameObject dead;
	private float start;
	private float timestamp;
	private bool hit = false;
	private int score;
	GameObject score_text;
	TextMesh text;
			// Use this for initialization
	void Start () {
		end = new Vector3(8, transform.position.y, transform.position.z);
		ship_pos = GameObject.FindGameObjectWithTag ("Player");
		score_text = GameObject.FindGameObjectWithTag ("score");
		text = score_text.GetComponent<TextMesh>();
		GetComponent<Rigidbody2D>().velocity = velocity;
		transform.position = new Vector3(Random.Range(-8, 8), transform.position.y, transform.position.z);
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetMouseButton(0)){
			if(ship_pos.transform.position.x > transform.position.x - 2 && ship_pos.transform.position.x < transform.position.x + 2 ){
				GetComponent<Rigidbody2D>().velocity = new Vector2(0,0);
				dead.SetActive(true);
				alive.SetActive(false);
				start = Time.time;
				hit = true;
				Debug.Log ("hit");

			}
		}
		if (hit) {
			timestamp = Time.time;
			if(timestamp > start + 1){
				Destroy(gameObject);
				hit = false;
				score = int.Parse(text.text);
				score++;
				text.text = score.ToString();
			}
		}
		if (transform.position.x >= end.x) {
			Destroy(gameObject);
				}

	}
}
