﻿using UnityEngine;
using System.Collections;

public class generate : MonoBehaviour {
	public GameObject attackship;
	public GameObject cows;
	private float speed = 4f;
	private float timestart = Time.time;
	private float timestamp;

	// Use this for initialization
	void Start () {
		InvokeRepeating ("createAttacker", speed, 1.5f);
		InvokeRepeating ("createCows", speed, 1.5f);
	}
	void createAttacker(){
		Instantiate (attackship);
	}

	void createCows(){
		Instantiate (cows);
	}
	// Update is called once per frame
	void Update () {
		if (speed != 1) {
			timestamp = Time.time;
			if(timestamp > timestart + 5.0){
				timestart = timestamp;
				speed -= .5f;
			}
		}
	
	}
}
